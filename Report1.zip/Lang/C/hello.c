#include <stdio.h>
int main()
{
     printf("Hello C world!!\n");

     return 0;
}
