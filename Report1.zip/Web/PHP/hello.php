<?
echo "Hello PHP world!!";
?>
